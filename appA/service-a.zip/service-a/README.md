# Service A

A minimal Flask service packaged as a Docker image and deployed to Amazon EKS.

```
service-a/
├── service_a.py        # Flask application
├── requirements.txt    # Python dependencies
├── Dockerfile          # Container image definition
├── .dockerignore
└── k8s/
    ├── deployment.yaml # Runs the pod
    └── service.yaml    # Exposes the pod
```

## Prerequisites

Docker, the AWS CLI (configured with `aws configure`), `kubectl`, and an existing EKS cluster.

## 1. Run locally

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
python service_a.py
curl http://localhost:8080/api/sa
```

## 2. Build and test the Docker image

```bash
docker build -t service-a:1.0 .
docker run --rm -p 8080:8080 service-a:1.0
curl http://localhost:8080/api/sa
```

> On an Apple Silicon Mac, EKS nodes are usually x86, so build with
> `docker build --platform linux/amd64 -t service-a:1.0 .`

## 3. Push the image to Amazon ECR

```bash
export AWS_REGION=us-east-1                     # change to your region
export ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
export REPO=$ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/service-a

aws ecr create-repository --repository-name service-a --region $AWS_REGION

aws ecr get-login-password --region $AWS_REGION \
  | docker login --username AWS --password-stdin $ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com

docker tag service-a:1.0 $REPO:1.0
docker push $REPO:1.0
```

## 4. Deploy to EKS

Point kubectl at your cluster:

```bash
aws eks update-kubeconfig --region $AWS_REGION --name <YOUR_CLUSTER_NAME>
```

Put your image URI into the deployment and apply the manifests:

```bash
sed -i.bak "s|<ACCOUNT_ID>.dkr.ecr.<REGION>.amazonaws.com/service-a|$REPO|" k8s/deployment.yaml
kubectl apply -f k8s/
```

Check that the pod is running:

```bash
kubectl get pods -l app=service-a
kubectl logs -l app=service-a
```

## 5. Call the service

Through the load balancer (it can take a couple of minutes for the hostname to appear and resolve):

```bash
kubectl get svc service-a
curl http://<EXTERNAL-HOSTNAME>/api/sa
```

Or without a load balancer, via port-forwarding:

```bash
kubectl port-forward svc/service-a 8080:80
curl http://localhost:8080/api/sa
```

## Clean up

```bash
kubectl delete -f k8s/
aws ecr delete-repository --repository-name service-a --region $AWS_REGION --force
```

## Troubleshooting

`ImagePullBackOff` usually means the node IAM role lacks ECR read access (attach `AmazonEC2ContainerRegistryReadOnly`) or the image URI/tag is wrong. `exec format error` in the logs means the image was built for the wrong CPU architecture; rebuild with `--platform linux/amd64`.
